# startup.py -- Hub Subsystem 2 -- Team 308 -- Adrian P
# Boot sequence: ESP-NOW init, UART ping.
# No WiFi, MQTT, or OLED required for the hub.

import time
import config
import leds

def _log(tag, msg):
    print('[{}] {}'.format(tag, msg))

# -- ESP-NOW ------------------------------------------------------------------

def init_espnow():
    """
    Initialise ESP-NOW and register Sam B.
    Returns (espnow_obj, ok_bool).
    """
    if not config.ESPNOW_ENABLE:
        _log('ESPNOW', 'Disabled in config')
        return None, False

    _log('ESPNOW', 'Initialising...')
    try:
        import espnow
        import network
        wlan = network.WLAN(network.STA_IF)
        wlan.active(True)

        e = espnow.ESPNow()
        e.active(True)

        for mac_list, name in [
            (config.SAM_B_MAC,  'Sam B (upstream)'),
        ]:
            mac = bytes(mac_list)
            e.add_peer(mac)
            mac_str = ':'.join('{:02X}'.format(b) for b in mac_list)
            _log('ESPNOW', 'Registered {} -- {}'.format(name, mac_str))

        leds.boot_espnow_ok()
        time.sleep_ms(5000)
        return e, True

    except ImportError:
        _log('ESPNOW', 'No espnow module -- UART only')
        leds.boot_espnow_fail()
        time.sleep_ms(5000)
        return None, False

    except Exception as ex:
        _log('ESPNOW', 'FAILED: {}'.format(ex))
        leds.boot_espnow_fail()
        time.sleep_ms(5000)
        return None, False

# -- UART ping ----------------------------------------------------------------

def uart_ping(uart):
    """
    Send a ping to Sam B (upstream) and wait up to 1.5 s for a reply.
    Returns True if someone answers.
    """
    from protocol import PREFIX, SUFFIX, MY_ID
    ping = PREFIX + MY_ID + '1' + 'P' + SUFFIX
    _log('UART', 'Pinging Sam B...')
    uart.write(ping.encode())

    deadline = time.ticks_add(time.ticks_ms(), 1500)
    buf = ''
    while time.ticks_diff(deadline, time.ticks_ms()) > 0:
        if uart.any():
            raw = uart.read()
            if raw:
                try:
                    buf += raw.decode('utf-8', 'ignore')
                except Exception:
                    pass
                s = buf.find(PREFIX)
                e = buf.find(SUFFIX, s + 2) if s != -1 else -1
                if s != -1 and e != -1:
                    payload = buf[s + 2: e]
                    sender  = payload[0] if payload else ''
                    if sender == MY_ID:
                        buf = buf[e + 2:]
                        continue
                    if sender == '1':
                        _log('UART', 'Sam B replied: {}'.format(buf.strip()))
                        leds.boot_uart_ok()
                        time.sleep_ms(600)
                        return True
                    buf = buf[e + 2:]
        time.sleep_ms(50)

    _log('UART', 'No reply from Sam B')
    leds.boot_uart_fail()
    time.sleep_ms(5000)
    return False

# -- Full boot ----------------------------------------------------------------

def run(uart):
    _log('BOOT', '=== Hub Sub2 Team308 (Adrian) ===')
    print('[BOOT] -- Hub')

    enow, enow_ok = init_espnow()
    uart_ok       = uart_ping(uart)

    leds.boot_complete()

    _log('BOOT', 'ESPNOW:{} UART:{}'.format(
        'OK' if enow_ok else 'FAIL',
        'OK' if uart_ok else 'NO'))

    return {
        'espnow'   : enow,
        'espnow_ok': enow_ok,
        'uart_ok'  : uart_ok,
    }
