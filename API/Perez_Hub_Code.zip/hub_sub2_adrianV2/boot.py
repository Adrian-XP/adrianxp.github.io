# boot.py -- Hub Subsystem 2 -- Team 308 -- Adrian P
