# protocol.py -- Hub Subsystem 2 -- Team 308 -- Adrian P
#
# Frame:  AZ + sender + receiver + msg_type + data + YB
# All fields are single ASCII characters.
# Types above 9 use hex char: type 10='A', 12='C', 13='D', 14='E', 15='F'
# Type 20 = chr(20) directly.
#
# Subsystem table:
#   1 = Sam B  (HMI)
#   2 = Adrian (Hub)   <-- ME
#   3 = Andrew (IMU)
#   4 = Jacob  (Motors)
#   5 = Sam M  (Temp)
#   6 = Mo     (Light)

PREFIX  = 'AZ'
SUFFIX  = 'YB'
MY_ID   = '2'        # Adrian -- Hub

# Receiver shortcuts
HMI     = '1'
ANDREW  = '3'
JACOB   = '4'
SAMM    = '5'
MO      = '6'

# Type char constants
T_MOTOR_SET    = '1'        # type 1  -- motor speed set
T_MOTOR_INFO   = '2'        # type 2  -- status response (hub sends)
T_SENSOR       = '3'        # type 3  -- sensor value
T_ERROR_ALERT  = 'A'        # type 10 -- error alert
T_STATUS       = 'C'        # type 12 -- status request/response
T_STATUS_FWD   = 'D'        # type 13 -- status forwarded
T_ERROR_ACK    = 'E'        # type 14 -- error ACK
T_STATUS_RESP  = 'F'        # type 15 -- status code response
T_HUB_CMD      = chr(20)    # type 20 -- hub command (received by us)
T_BUTTON       = '43'       # type 67 -- button press (two chars)

# Subsystem names for logging
SUBSYS = {
    '1': 'Sam B',
    '2': 'Adrian',
    '3': 'Andrew',
    '4': 'Jacob',
    '5': 'Sam M',
    '6': 'Mo',
}

# Valid sender IDs
KNOWN_SENDERS = {'1', '2', '3', '4', '5', '6'}

# Hub's own subsystem number as reported in status/error payloads
HUB_SUBSYS_NUM = '2'   # per API spec: subsystem_number = 3 for hub messages

def _clamp(v, lo, hi):
    return max(lo, min(hi, int(v)))

# ── Type char ↔ int conversion ────────────────────────────────────────────────

def _type_int(ch):
    """Convert type char to int.  Handles hex chars A-F and raw chr() values."""
    try:
        return int(ch, 16)
    except Exception:
        return ord(ch)

# ── Outbound builders ─────────────────────────────────────────────────────────

def build_status_response(status_code, data_value=0):
    """
    Type 2 -- Hub status response back to HMI (Sam B).
    status_code : 0-10
    data_value  : -100..100  signed
    Packet: AZ 2 1 '2' subsys_num status_code data_value YB
    """
    sc = _clamp(status_code, 0, 10)
    dv = _clamp(data_value, -100, 100)
    # data_value encoded as unsigned offset (100 bias) so it stays ASCII-printable
    # We transmit as two chars: sign ('P'=positive/zero, 'N'=negative) + magnitude
    sign = 'P' if dv >= 0 else 'N'
    mag  = abs(dv)
    return (PREFIX + MY_ID + HMI +
            T_MOTOR_INFO + HUB_SUBSYS_NUM + str(sc) + sign + str(mag) + SUFFIX)

def build_error_message(error_code, sensor_id=0):
    """
    Type 14 -- Hub error report to HMI.
    error_code : 0-10
    sensor_id  : 0-15
    """
    ec = _clamp(error_code, 0, 10)
    si = _clamp(sensor_id, 0, 15)
    return (PREFIX + MY_ID + HMI +
            T_ERROR_ACK + HUB_SUBSYS_NUM + str(ec) + str(si) + SUFFIX)

def build_forward(raw_pkt, new_receiver):
    """
    Re-frame a received packet with our ID as sender toward new_receiver.
    Used when we need to relay a message downstream.
    raw_pkt     : original string (we strip and re-wrap)
    new_receiver: single char subsystem ID
    """
    if not (raw_pkt.startswith(PREFIX) and raw_pkt.endswith(SUFFIX)):
        return raw_pkt  # can't re-frame; pass as-is
    inner = raw_pkt[len(PREFIX):-len(SUFFIX)]
    if len(inner) < 3:
        return raw_pkt
    # Keep original sender + type + data, just change the receiver field
    # (sender[0] + receiver[1] + type[2] + data[3:])
    return PREFIX + inner[0] + new_receiver + inner[2:] + SUFFIX

def build_ack_ping(target):
    """Generic ping ACK back to target."""
    return PREFIX + MY_ID + target + 'P' + SUFFIX

# ── Inbound parser ────────────────────────────────────────────────────────────

def parse(pkt):
    """
    Parse a raw ASCII packet string.
    Returns dict with:
      valid, sender, receiver, type_char, type_int, data, summary
      + type-specific fields for types the hub cares about.
    """
    if not (pkt.startswith(PREFIX) and pkt.endswith(SUFFIX)):
        return {'valid': False, 'reason': 'bad frame: {}'.format(pkt)}

    payload = pkt[len(PREFIX):-len(SUFFIX)]
    if len(payload) < 3:
        return {'valid': False, 'reason': 'too short'}

    sender    = payload[0]
    receiver  = payload[1]
    type_char = payload[2]
    data      = payload[3:]
    t         = _type_int(type_char)

    r = {
        'valid'    : True,
        'sender'   : sender,
        'receiver' : receiver,
        'type_char': type_char,
        'type_int' : t,
        'data'     : data,
        'summary'  : 'T{} from {}'.format(t, SUBSYS.get(sender, 'Sub' + sender)),
    }

    try:
        if t == 1 and len(data) >= 2:
            # Motor speed set -- forward to Jacob
            r.update({
                'motor_id' : data[0] if data else '?',
                'summary'  : 'MotorSet id={} spd={}'.format(
                    data[0] if data else '?', data[1] if len(data)>1 else '?'),
            })

        elif t == 2 and len(data) >= 2:
            # Status response (from another sub) -- forward to HMI
            r.update({
                'status_code': data[0],
                'summary'    : 'StatusResp code={}'.format(data[0]),
            })

        elif t == 3 and len(data) >= 1:
            # Sensor value -- forward to HMI
            sensor_num = data[0]
            upper = int(data[1]) if len(data) > 1 else 0
            lower = int(data[2]) if len(data) > 2 else 0
            value = (upper << 8) | lower
            r.update({
                'sensor_num': sensor_num,
                'sensor_val': value,
                'summary'   : 'Sensor#{} = {}'.format(sensor_num, value),
            })

        elif t == 10 and len(data) >= 2:
            # Error alert from a subsystem
            r.update({
                'error_code': data[0],
                'error_from': data[1] if len(data) > 1 else '?',
                'summary'   : 'ERR {} from {}'.format(
                    data[0], SUBSYS.get(data[1], 'Sub'+data[1]) if len(data)>1 else '?'),
            })

        elif t == 12 and len(data) >= 2:
            # Type 12 -- Status request (may be for us or to forward)
            subsys_num   = data[0]
            request_code = data[1] if len(data) > 1 else '0'
            r.update({
                'subsys_num'  : subsys_num,
                'request_code': request_code,
                'for_hub'     : (subsys_num == HUB_SUBSYS_NUM),
                'summary'     : 'StatusReq sub={} code={}'.format(
                    subsys_num, request_code),
            })

        elif t == 20:
            # Type 20 -- Hub command (addressed to us)
            subsys_num   = data[0] if data else '?'
            command_code = data[1] if len(data) > 1 else '0'
            # command_value is signed -100..100, stored as next char
            try:
                cmd_val = int(data[2:]) if len(data) > 2 else 0
                cmd_val = _clamp(cmd_val, -100, 100)
            except Exception:
                cmd_val = 0
            r.update({
                'subsys_num'  : subsys_num,
                'command_code': command_code,
                'command_val' : cmd_val,
                'summary'     : 'HubCmd code={} val={}'.format(command_code, cmd_val),
            })

        elif t == 67 and len(data) >= 2:
            # Button press -- forward downstream
            r.update({
                'button_num'  : data[0],
                'button_state': data[1],
                'summary'     : 'Btn#{} state={}'.format(data[0], data[1]),
            })

    except Exception as e:
        r['summary'] = r['summary'] + ' (parse err: {})'.format(e)
        print('[PROTO] parse error: {}'.format(e))

    return r
