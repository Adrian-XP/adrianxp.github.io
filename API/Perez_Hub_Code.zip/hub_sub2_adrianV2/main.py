# main.py -- Hub Subsystem 2 -- Team 308 -- Adrian P
#
# The Hub sits in the middle of the daisy-chain:
#
#   [Sam B HMI] <--UART/ESP--> [Hub (Me)] <--UART/ESP--> [Andrew / downstream]
#
# Routing rules (per team spec):
#   Packet FOR ME      → process and respond
#   Packet for OTHERS  → forward downstream (or upstream) unchanged
#   Packet FROM ME     → loopback, trash
#   Unknown sender     → error, trash
#   Malformed packet   → error, trash
#
# Messages I process:
#   Type 12 (C) -- Status request where subsystem_number == 3 (hub)
#   Type 20     -- Hub command (always for me by definition)
#
# Messages I forward upstream (toward Sam B):
#   Type 2  -- Status response from downstream subs
#   Type 3  -- Sensor values from downstream subs
#   Type 10 -- Error alerts from downstream subs
#   Type 14 -- Error ACK from downstream subs
#
# Messages I forward downstream (toward Andrew/Jacob/etc):
#   Type 1  -- Motor speed set from HMI
#   Type 3  -- Sensor requests from HMI
#   Type 12 -- Status requests NOT for hub
#   Type 67 -- Button press events
#
# Messages I originate:
#   Type 2  -- Hub status response (to HMI)
#   Type 14 -- Hub error message (to HMI)

from machine import UART, Pin
import time
import sys
import network
import ubinascii

import config
import startup
import protocol
import msglog
import leds

# -- MAC address print (run once at boot so team can copy values) -------------
def _print_mac():
    try:
        wlan = network.WLAN(network.STA_IF)
        wlan.active(True)
        sta_mac = ubinascii.hexlify(wlan.config('mac'), ':').decode().upper()
        ap = network.WLAN(network.AP_IF)
        ap.active(True)
        ap_mac = ubinascii.hexlify(ap.config('mac'), ':').decode().upper()

        def _mac_list(s):
            return '[' + ', '.join('0x' + b for b in s.split(':')) + ']'

        print('=' * 44)
        print('Hub Sub2 (Adrian) -- MAC Addresses')
        print('=' * 44)
        print('WiFi STA : {}'.format(sta_mac))
        print('WiFi AP  : {}'.format(ap_mac))
        print()
        print('For teammates -- paste into their config.py:')
        print('ADRIAN_MAC = {}'.format(_mac_list(sta_mac)))
        print('=' * 44)
    except Exception as ex:
        print('[MAC] Could not read MAC: {}'.format(ex))

_print_mac()

# -- Hardware -----------------------------------------------------------------
uart = UART(config.UART_ID, baudrate=config.UART_BAUD,
            tx=config.UART_TX, rx=config.UART_RX)

# -- Boot ---------------------------------------------------------------------
boot   = startup.run(uart)
espnow = boot['espnow']

msglog.add_sys('Boot E:{} U:{}'.format(
    'Y' if boot['espnow_ok'] else 'N',
    'Y' if boot['uart_ok']  else 'N'))

# -- Hub internal state -------------------------------------------------------
_hub_status_code = 0    # 0 = OK, non-zero = error/busy
_hub_data_value  = 0    # last data value reported by hub
_last_error_code = 0    # most recent error code seen
_last_error_from = '?' # subsystem that sent the last error

# -- TX helper ----------------------------------------------------------------

def _send(pkt, summary, type_int=0):
    """Transmit on UART and optionally ESP-NOW; log it; blink LED."""
    uart.write(pkt.encode())
    print('[TX] {}'.format(pkt))
    msglog.add_tx(summary)
    leds.evt_tx(type_int)

    if espnow:
        # Determine target MAC based on receiver field
        receiver = pkt[len(protocol.PREFIX)] if len(pkt) > len(protocol.PREFIX) else '?'
        # Only ESP-NOW to Sam B (upstream); downstream goes over UART
        if receiver == protocol.HMI:
            try:
                espnow.send(bytes(config.SAM_B_MAC), pkt.encode())
                leds.evt_espnow_activity()
            except Exception as ex:
                print('[ESPNOW] TX err: {}'.format(ex))

# -- Forwarding helpers -------------------------------------------------------

def _forward_downstream(pkt, summary):
    """Forward a packet toward Andrew/Jacob (downstream UART)."""
    uart.write(pkt.encode())
    print('[FWD→] {}'.format(pkt))
    msglog.add_fwd('→down: ' + summary)
    leds.evt_rx_forward()

def _forward_upstream(pkt, summary):
    """Forward a packet toward Sam B (upstream UART + ESP-NOW)."""
    uart.write(pkt.encode())
    print('[FWD←] {}'.format(pkt))
    msglog.add_fwd('←up: ' + summary)
    leds.evt_rx_forward()
    if espnow:
        try:
            espnow.send(bytes(config.SAM_B_MAC), pkt.encode())
            leds.evt_espnow_activity()
        except Exception as ex:
            print('[ESPNOW] FWD err: {}'.format(ex))

# -- Command processor --------------------------------------------------------

def _handle_hub_command(parsed):
    """
    Process Type 20 -- Hub Command.
    command_code : 0-10
    command_val  : -100..100 signed
    Respond with Type 2 status response to HMI.
    """
    global _hub_status_code, _hub_data_value

    code = parsed.get('command_code', '0')
    val  = parsed.get('command_val', 0)

    # Validate range per spec
    try:
        code_int = int(code)
        if not (0 <= code_int <= 10):
            print('[CMD] Invalid command_code {}, ignoring'.format(code_int))
            return
    except Exception:
        print('[CMD] Non-numeric command_code, ignoring')
        return

    try:
        val_int = int(val)
        if not (-100 <= val_int <= 100):
            print('[CMD] Invalid command_val {}, clamping'.format(val_int))
            val_int = max(-100, min(100, val_int))
    except Exception:
        val_int = 0

    print('[CMD] Hub command code={} val={}'.format(code_int, val_int))

    # Execute command
    if code_int == 0:
        # Code 0: report current status
        _hub_data_value  = val_int
        _hub_status_code = 0
    elif code_int == 1:
        # Code 1: set data value
        _hub_data_value = val_int
        _hub_status_code = 0
    else:
        # Unknown command -- log it but acknowledge
        print('[CMD] Unhandled command code {}'.format(code_int))
        _hub_status_code = code_int  # echo code as status

    # Always respond with Type 2 status response
    resp = protocol.build_status_response(_hub_status_code, _hub_data_value)
    _send(resp, 'HubStsResp code={} val={}'.format(_hub_status_code, _hub_data_value), 2)

def _handle_status_request(parsed):
    """
    Process Type 12 addressed to hub (subsystem_number == 3).
    Respond with Type 2 status response.
    """
    req_code = parsed.get('request_code', '0')
    print('[HUB] Status request code={}'.format(req_code))

    resp = protocol.build_status_response(_hub_status_code, _hub_data_value)
    _send(resp, 'StsResp code={}'.format(_hub_status_code), 2)

def _handle_error_alert(parsed, raw_pkt):
    """
    Type 10 error from downstream -- log, LED, forward upstream, then ACK.
    """
    global _last_error_code, _last_error_from
    ec = parsed.get('error_code', '?')
    ef = parsed.get('error_from', '?')
    _last_error_code = ec
    _last_error_from = ef

    print('[ERR] Alert code={} from sub{}'.format(ec, ef))
    leds.evt_error_alert(True)
    msglog.add_err('ERR {} sub{}'.format(ec, ef))

    # Forward upstream so HMI can display it
    _forward_upstream(raw_pkt, 'ERR fwd upstream')

    # Brief pause so HMI can see it, then clear error LED
    time.sleep_ms(200)
    leds.evt_error_alert(False)

# -- RX buffer & processor ----------------------------------------------------
_rx_buf = ''

def _poll_rx():
    global _rx_buf

    # UART
    if uart.any():
        raw = uart.read()
        if raw:
            try:
                _rx_buf += raw.decode('utf-8', 'ignore')
            except Exception:
                pass

    # ESP-NOW
    if espnow:
        try:
            host, msg = espnow.recv(0)
            if msg:
                try:
                    _rx_buf += msg.decode('utf-8', 'ignore')
                except Exception:
                    pass
                leds.evt_espnow_activity()
                print('[ESPNOW] RX: {}'.format(msg))
        except Exception:
            pass

    # Frame extraction
    while True:
        s = _rx_buf.find(protocol.PREFIX)
        if s == -1:
            _rx_buf = _rx_buf[-4:]
            return
        e = _rx_buf.find(protocol.SUFFIX, s + 2)
        if e == -1:
            return
        pkt = _rx_buf[s: e + 2]
        _rx_buf = _rx_buf[e + 2:]
        _handle_rx(pkt)


def _handle_rx(pkt):
    """Route one extracted packet."""
    parsed = protocol.parse(pkt)

    # -- Malformed ------------------------------------------------------------
    if not parsed['valid']:
        reason = parsed.get('reason', 'bad pkt')
        print('[RX] Invalid: {}'.format(reason))
        msglog.add_err(reason)
        leds.evt_bad_packet()
        return

    sender   = parsed['sender']
    receiver = parsed['receiver']
    t        = parsed['type_int']

    # -- Loopback guard -------------------------------------------------------
    if sender == protocol.MY_ID:
        print('[RX] Loopback suppressed')
        return

    # -- Unknown sender -------------------------------------------------------
    if sender not in protocol.KNOWN_SENDERS:
        print('[RX] Unknown sender {}'.format(sender))
        msglog.add_err('Unknown sender {}'.format(sender))
        leds.evt_bad_packet()
        return

    print('[RX] T={} from={} to={} {}'.format(
        t, sender, receiver, parsed['summary']))

    # -- Packets NOT addressed to hub -----------------------------------------
    if receiver != protocol.MY_ID:
        # Determine direction: if from HMI (upstream) → send downstream; else → upstream
        if sender == protocol.HMI:
            _forward_downstream(pkt, parsed['summary'])
        else:
            _forward_upstream(pkt, parsed['summary'])
        return

    # -- Packets addressed to hub (receiver == MY_ID) -------------------------
    msglog.add_rx(parsed)

    if t in (2, 3, 10, 12, 20):
        leds.evt_rx_important(t)

    # Type 12 -- Status request
    if t == 12:
        subsys_num = parsed.get('subsys_num', '?')
        if subsys_num == protocol.HUB_SUBSYS_NUM:
            # Request is genuinely for the hub
            _handle_status_request(parsed)
        else:
            # Forward downstream -- hub is a relay for requests to other subs
            _forward_downstream(pkt, parsed['summary'])

    # Type 20 -- Hub command
    elif t == 20:
        _handle_hub_command(parsed)

    # Type 10 -- Error alert (from downstream, addressed to hub for relay)
    elif t == 10:
        _handle_error_alert(parsed, pkt)

    # Type 2 -- Status response from a downstream sub; relay upstream
    elif t == 2:
        _forward_upstream(pkt, parsed['summary'])

    # Type 3 -- Sensor value from downstream; relay upstream
    elif t == 3:
        _forward_upstream(pkt, parsed['summary'])

    # Type 14 -- Error ACK from downstream; relay upstream
    elif t == 14:
        leds.evt_rx_important(14)
        _forward_upstream(pkt, parsed['summary'])

    # Type 15 -- Status code response; relay upstream
    elif t == 15:
        _forward_upstream(pkt, parsed['summary'])

    # Type 1 -- Motor speed set from HMI; forward downstream
    elif t == 1:
        _forward_downstream(pkt, parsed['summary'])

    # Type 67 -- Button press from HMI; forward downstream
    elif t == 67:
        _forward_downstream(pkt, parsed['summary'])

    # Ping
    elif parsed.get('type_char') == 'P':
        print('[HUB] Ping from sub{} -- ACK'.format(sender))
        ack = protocol.build_ack_ping(sender)
        _send(ack, 'PingACK to sub{}'.format(sender), 0)

    else:
        print('[HUB] Unhandled type {} -- forwarding downstream'.format(t))
        _forward_downstream(pkt, parsed['summary'])


# -- Terminal input (non-blocking REPL-style packet sender) -------------------
#
# Type a command in the serial terminal and press Enter.
# The hub reads stdin one character at a time without blocking the main loop.
#
# Commands:
#   send <raw_packet>         -- send a raw AZ...YB packet verbatim
#                                e.g.: send AZ213C0YB
#   status                    -- send a Type 2 hub status response to HMI
#   error <code> [sensor_id]  -- send a Type 14 error message to HMI
#                                e.g.: error 3 1
#   ping <sub_id>             -- send a ping to subsystem N (1-6)
#                                e.g.: ping 1
#   log                       -- dump the message log to terminal
#   mac                       -- reprint MAC addresses
#   help                      -- show this list

_stdin_buf = ''

def _print_help():
    print('=' * 44)
    print('Hub terminal commands:')
    print('  send <AZ...YB>        raw packet')
    print('  status                send Type 2 status to HMI')
    print('  error <code> [sid]    send Type 14 error to HMI')
    print('  ping <sub_id>         ping subsystem 1-6')
    print('  log                   dump message log')
    print('  mac                   reprint MAC addresses')
    print('  help                  this list')
    print('=' * 44)

def _process_terminal_line(line):
    """Parse and execute one terminal command line."""
    line = line.strip()
    if not line:
        return

    parts = line.split()
    cmd   = parts[0].lower()

    if cmd == 'send':
        if len(parts) < 2:
            print('[TERM] Usage: send <AZ...YB>')
            return
        pkt = parts[1]
        if not (pkt.startswith(protocol.PREFIX) and pkt.endswith(protocol.SUFFIX)):
            print('[TERM] Bad frame -- must start with AZ and end with YB')
            return
        _send(pkt, 'manual: {}'.format(pkt), 0)
        print('[TERM] Sent: {}'.format(pkt))

    elif cmd == 'status':
        pkt = protocol.build_status_response(_hub_status_code, _hub_data_value)
        _send(pkt, 'manual status resp', 2)
        print('[TERM] Status response sent (code={} val={})'.format(_hub_status_code, _hub_data_value))

    elif cmd == 'error':
        try:
            ec = int(parts[1]) if len(parts) > 1 else 0
            si = int(parts[2]) if len(parts) > 2 else 0
        except ValueError:
            print('[TERM] Usage: error <code 0-10> [sensor_id 0-15]')
            return
        pkt = protocol.build_error_message(ec, si)
        _send(pkt, 'manual error code={} sid={}'.format(ec, si), 14)
        print('[TERM] Error message sent (code={} sensor={})'.format(ec, si))

    elif cmd == 'ping':
        if len(parts) < 2:
            print('[TERM] Usage: ping <sub_id 1-6>')
            return
        try:
            target = str(int(parts[1]))
        except ValueError:
            print('[TERM] sub_id must be 1-6')
            return
        if target not in protocol.KNOWN_SENDERS:
            print('[TERM] Unknown sub_id {}'.format(target))
            return
        pkt = protocol.build_ack_ping(target)
        _send(pkt, 'manual ping sub{}'.format(target), 0)
        print('[TERM] Ping sent to sub{} ({})'.format(
            target, protocol.SUBSYS.get(target, '?')))

    elif cmd == 'log':
        msglog.dump()

    elif cmd == 'mac':
        _print_mac()

    elif cmd == 'help':
        _print_help()

    else:
        print('[TERM] Unknown command "{}". Type help for list.'.format(cmd))

def _poll_stdin():
    """
    Non-blocking stdin read.  MicroPython uos.dupterm / sys.stdin is
    character-at-a-time; we accumulate into _stdin_buf and process on newline.
    """
    global _stdin_buf
    try:
        # select() is not available on all builds; use a single-char read with
        # a 0-ms timeout via the poll approach that works on ESP32 MicroPython.
        import uselect
        poller = uselect.poll()
        poller.register(sys.stdin, uselect.POLLIN)
        ready = poller.poll(0)   # 0 ms -- non-blocking
        if not ready:
            return
        ch = sys.stdin.read(1)
        if not ch:
            return
        if ch in ('\n', '\r'):
            _process_terminal_line(_stdin_buf)
            _stdin_buf = ''
        else:
            _stdin_buf += ch
    except Exception:
        # uselect not available or stdin not readable -- silently skip
        pass

# -- Main loop ----------------------------------------------------------------
print('[HUB] Adrian Sub2 ready -- routing started')
print('[HUB] Type "help" in terminal for manual packet commands')

while True:
    _poll_rx()
    _poll_stdin()
    leds.poll()
    time.sleep_ms(10)
