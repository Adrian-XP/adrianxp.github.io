# msglog.py -- Hub Subsystem 2 -- Team 308 -- Adrian P
# Lightweight terminal-only message log (no OLED on hub).

MAX_MSGS = 20

TAG_RX  = '<'
TAG_TX  = '>'
TAG_FWD = 'F'
TAG_ERR = '!'
TAG_SYS = '*'

_log = []   # list of (tag, summary_str)

def add(tag, summary):
    _log.append((tag, str(summary)[:40]))
    if len(_log) > MAX_MSGS:
        _log.pop(0)
    print('[LOG] {} {}'.format(tag, summary))

def add_rx(parsed):
    add(TAG_RX, parsed.get('summary', 'unknown'))

def add_tx(summary):
    add(TAG_TX, summary)

def add_fwd(summary):
    add(TAG_FWD, summary)

def add_err(reason):
    add(TAG_ERR, reason)

def add_sys(msg):
    add(TAG_SYS, msg)

def dump():
    """Print all log entries to terminal."""
    print('[LOG DUMP] --- {} entries ---'.format(len(_log)))
    for tag, summary in _log:
        print('  {} {}'.format(tag, summary))
    print('[LOG DUMP] --- end ---')

def clear():
    _log.clear()
    print('[LOG] Cleared')
