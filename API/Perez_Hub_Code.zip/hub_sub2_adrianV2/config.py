# config.py -- Hub Subsystem 2 -- Team 308 -- Adrian P

# -- ESP-NOW ------------------------------------------------------------------
SAM_B_MAC     = [0xD4, 0xBC, 0x49, 0xE2, 0x20, 0xCC]  # PLACEHOLDER -- Sam B (Sub 1)
ESPNOW_ENABLE = True

# -- UART ---------------------------------------------------------------------
UART_ID   = 2
UART_TX   = 17
UART_RX   = 16
UART_BAUD = 9600

# -- LEDs (active HIGH) -------------------------------------------------------
LED_TXRX_PIN = 21   # Send / Receive activity
LED_ERR_PIN  = 22   # Error indicator
LED_ESP_PIN  = 23   # ESP-NOW link status