# leds.py -- Hub Subsystem 2 -- Team 308 -- Adrian P
#
# LED1 (GPIO 21) -- TX / RX activity
#   TX packet      : 1 quick blink (skips Type 1 motor spam)
#   RX important   : 2 quick blinks (status, error, sensor, hub command)
#   RX forwarded   : 1 slow blink
#
# LED2 (GPIO 22) -- Error indicator
#   Bad packet     : 500 ms ON
#   Error alert (T10) : rapid blink until cleared
#   Boot fail      : stays ON solid
#
# LED3 (GPIO 23) -- ESP-NOW link
#   Boot ESP OK    : 3 blinks then stays ON
#   Boot ESP FAIL  : stays OFF
#   ESP-NOW TX/RX  : single blink

from machine import Pin
import time
import config

# -- Hardware -----------------------------------------------------------------
_led_txrx = Pin(config.LED_TXRX_PIN, Pin.OUT)
_led_err  = Pin(config.LED_ERR_PIN,  Pin.OUT)
_led_esp  = Pin(config.LED_ESP_PIN,  Pin.OUT)

def _on(led):  led.value(1)
def _off(led): led.value(0)

# -- State --------------------------------------------------------------------
_err_blink_active = False
_err_blink_until  = 0
_esp_link_ok      = False

# -- Blocking helpers (boot only) ---------------------------------------------

def _blink(led, n, on_ms=120, off_ms=120):
    for i in range(n):
        _on(led)
        time.sleep_ms(on_ms)
        _off(led)
        if i < n - 1:
            time.sleep_ms(off_ms)

# -- Boot sequence ------------------------------------------------------------

def boot_espnow_ok():
    """3 blinks then LED3 stays ON."""
    global _esp_link_ok
    _blink(_led_esp, 3, on_ms=150, off_ms=100)
    time.sleep_ms(200)
    _on(_led_esp)
    _esp_link_ok = True
    print('[LED] ESP-NOW OK -- LED3 on')

def boot_espnow_fail():
    """LED3 stays OFF, LED2 blinks twice as warning."""
    global _esp_link_ok
    _esp_link_ok = False
    _off(_led_esp)
    _blink(_led_err, 2, on_ms=200, off_ms=150)
    _off(_led_err)
    print('[LED] ESP-NOW FAIL')

def boot_uart_ok():
    """LED1 single long blink -- UART peer found."""
    _blink(_led_txrx, 1, on_ms=400)
    print('[LED] UART OK')

def boot_uart_fail():
    """LED2 one blink -- UART no peer."""
    _blink(_led_err, 1, on_ms=300)
    _off(_led_err)
    print('[LED] UART no peer')

def boot_complete():
    """All green -- brief flash both activity LEDs."""
    _blink(_led_txrx, 2, on_ms=80, off_ms=80)
    if _esp_link_ok:
        _on(_led_esp)
    print('[LED] Boot complete')

# -- Runtime event triggers ---------------------------------------------------

def evt_tx(type_int):
    """1 quick blink on LED1.  Skips Type 1 (motor) to avoid strobing."""
    if type_int == 1:
        return
    _blink(_led_txrx, 1, on_ms=40, off_ms=0)

def evt_rx_important(type_int):
    """2 quick blinks on LED1 for status/error/sensor/hub-command."""
    _blink(_led_txrx, 2, on_ms=40, off_ms=40)

def evt_rx_forward():
    """1 slow blink on LED1 for forwarded packets."""
    _blink(_led_txrx, 1, on_ms=200, off_ms=0)

def evt_espnow_activity():
    """Single blink on LED3 for ESP-NOW TX or RX."""
    _blink(_led_esp, 1, on_ms=60, off_ms=0)
    if _esp_link_ok:
        _on(_led_esp)

def evt_bad_packet():
    """LED2 ON for 500 ms -- poll() will clear it."""
    global _err_blink_until
    _on(_led_err)
    _err_blink_until = time.ticks_add(time.ticks_ms(), 500)
    print('[LED] Bad packet -- LED2 500ms')

def evt_error_alert(active=True):
    """
    Type 10 error in flight -- LED2 rapid blink.
    Call evt_error_alert(False) once ACK is sent.
    """
    global _err_blink_active
    _err_blink_active = active
    if not active:
        _off(_led_err)
    print('[LED] Error mode: {}'.format(active))

def evt_espnow_lost():
    """ESP link dropped -- LED3 off."""
    global _esp_link_ok
    _esp_link_ok = False
    _off(_led_esp)
    print('[LED] ESP-NOW lost')

def evt_espnow_restored():
    """ESP link back -- LED3 on."""
    global _esp_link_ok
    _esp_link_ok = True
    _on(_led_esp)
    print('[LED] ESP-NOW restored')

# -- Poll (call every main loop tick) -----------------------------------------
_err_pulse_state = 0
_err_pulse_last  = 0

def poll():
    """Non-blocking LED maintenance.  Call from main loop every tick."""
    global _err_blink_until, _err_pulse_state, _err_pulse_last

    now = time.ticks_ms()

    # Timed LED2 off
    if _err_blink_until and time.ticks_diff(now, _err_blink_until) >= 0:
        _off(_led_err)
        _err_blink_until = 0

    # Rapid blink in error mode
    if _err_blink_active:
        if time.ticks_diff(now, _err_pulse_last) >= 250:
            _err_pulse_state = 1 - _err_pulse_state
            _led_err.value(_err_pulse_state)
            _err_pulse_last = now
